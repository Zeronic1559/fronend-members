<template>
<Desktop/>
<Mobile/>
<Footer/>
</template>

<script setup>
import Desktop from "@/components/menu/Desktop.vue";
import Mobile from "@/components/menu/Mobile.vue";
import Footer from "@/components/menu/Footer.vue";

</script>

<style scoped></style>
