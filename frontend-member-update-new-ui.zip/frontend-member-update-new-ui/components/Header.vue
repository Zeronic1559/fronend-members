<template>
    <header>
    <logo></logo>
    <profile></profile>
  </header>
</template>

<script setup>
import Profile from '@/components/Profile'
import Logo from '@/components/Logo'
</script >

<style scoped>

</style>