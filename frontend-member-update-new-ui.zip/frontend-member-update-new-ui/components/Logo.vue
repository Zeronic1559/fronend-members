<template>
    <NuxtLink to="/">
        <img
        :src="`/meslot168/logo.png`"
        class="logo m-auto mb-8 md:w-[300px] w-[200px]"
        alt="meslot168"
        />
    </NuxtLink>
</template>

<script setup>

</script>

<style scoped>

</style>