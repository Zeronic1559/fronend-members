<template>
  <div class="border-b border-gray-200 my-6"></div>
</template>
