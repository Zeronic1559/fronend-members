<template>
    <div>
    </div>
</template>

<script setup>
definePageMeta({
    layout : 'auth'
})
</script>

<style lang="scss" scoped>

</style>