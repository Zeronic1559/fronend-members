export default [
  {
    id: 1,
    name: "Facebook",
  },
  {
    id: 2,
    name: "Line",
  },
  {
    id: 3,
    name: "Google",
  },
  {
    id: 4,
    name: "Instragram",
  },
  {
    id: 5,
    name: "YouTube",
  },
  {
    id: 6,
    name: "SMS",
  },
  {
    id: 7,
    name: "Friend",
  },
  {
    id: 8,
    name: "Other",
  },
];
