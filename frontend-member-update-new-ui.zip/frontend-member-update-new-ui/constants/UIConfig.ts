export enum UIConfig {
  INPUT_SIZE = "xl",
  BUTTON_SIZE = "xl",
}
