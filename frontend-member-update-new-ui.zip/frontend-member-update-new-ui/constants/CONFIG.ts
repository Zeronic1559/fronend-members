export enum LOCAL_STORAGE {
  AUTH_TOKEN = "auth.local.token",
}
