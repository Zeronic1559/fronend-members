export enum STATUS {
  SUCCESS = "success",
  ERROR = "error",
  LOADING = "loading",
}
